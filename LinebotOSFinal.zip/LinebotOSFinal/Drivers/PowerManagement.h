/*
 * PowerManagement.h
 *
 * Created: 7/11/2023 14:36:42
 *  Author: maxco
 */ 


#ifndef POWERMANAGEMENT_H_
#define POWERMANAGEMENT_H_


void enterSleepMode(void);


#endif /* POWERMANAGEMENT_H_ */