#ifndef TEMPLATE_TASK_H
#define TEMPLATE_TASK_H

void InitTemplateTask(void);

#endif